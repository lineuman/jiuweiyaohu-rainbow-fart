# 九尾妖狐-阿狸 rainbow-fart 语音包

> 阿狸是漂亮的法师型刺客，声音甜美销魂，身材苗条性感，是造型控的首选之一，谁不想一遍写代码一遍玩游戏呢？

这是一个 vscode 彩虹屁🌈插件 [vscode-rainbow-fart](https://github.com/SaekiRaku/vscode-rainbow-fart) 的语音扩展包，灵感来源 [zthxxx](https://github.com/zthxxx/kugimiya-rainbow-fart)


语音来源：

[B站小伙伴](https://www.bilibili.com/video/BV1FW411X778?from=search&seid=2545271515529161195)

## 预览

![white](./result/white.png)

![dark](./result/dark.png)


## 安装

![import](./result/import.png)

